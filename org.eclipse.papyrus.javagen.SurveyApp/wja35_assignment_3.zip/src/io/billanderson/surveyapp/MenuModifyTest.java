package io.billanderson.surveyapp;

public class MenuModifyTest extends Menu {

}
